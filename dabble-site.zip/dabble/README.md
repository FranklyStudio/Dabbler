# Dabble

Static site, no build step.

1. Push this folder to a GitHub repo.
2. Settings → Pages → deploy from `main`, root folder.
3. Replace `YOUR-USERNAME` and `dabble` in `sitemap.xml` and `robots.txt`, and `you@example.com` in the footer and `privacy.html`.
4. After AdSense approval: add the script tag to each page's `<head>`, put your publisher line in `ads.txt`, and swap the "Advertisement" divs for your ad units.

Add a game: create `js/yourgame.js` (copy `clicks.js`), add an entry to `js/games.js`, and copy `clicks.html` to `yourgame.html`.
